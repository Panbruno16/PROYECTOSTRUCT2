# PROYECTO1Estruc
Realizar un sistema economico con dinamica de pobladores, conumas y servicios con recursos.
